public class BurrowsWheeler {

    /**
     * apply Burrows-Wheeler encoding, reading from standard input and writing to standard output
     */
    public static void encode() {

    }


    /**
     * apply Burrows-Wheeler decoding, reading from standard input and writing to standard output
     */
    public static void decode() {

    }

    /**
     * If args[0] is '-', apply Burrows-Wheeler encoding. If args[0] is '+', apply Burrows-Wheeler decoding
     *
     * @param args
     */
    public static void main(String[] args) {

    }
}