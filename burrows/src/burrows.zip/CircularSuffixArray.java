public class CircularSuffixArray {

    /**
     * circular suffix array of s
     *
     * @param s
     */
    public CircularSuffixArray(String s) {

    }

    /**
     * length of s
     *
     * @return
     */
    public int length() {
        return -1;
    }

    /**
     * returns index of ith sorted suffix
     *
     * @param i
     * @return
     */
    public int index(int i) {
        return -1;
    }

    /**
     * unit testing of the methods (optional)
     *
     * @param args
     */
    public static void main(String[] args) {

    }
}